/*
 * @file    main.c
 * @brief   Implementation file for the main module.
 * @details This file contains the implementation of the main module, including
 *          the main function, initialization functions, and other utility functions.
 *          It also includes necessary headers and sections for function prototypes,
 *          definitions, enums, structs/unions, and global variables.
 * @author  Chipsbank
 * @date    2024
 */
 
//-------------------------------
// INCLUDE SECTION
//-------------------------------
#include "main.h"
#if (APP_FREERTOS_ENABLE == APP_TRUE)
#include "AppSysRtos.h"
#else
#include "TaskHandler.h"
#endif
#include "app_uart.h"
#include "CB_system.h"
#include "AppUwbRadar.h"
#include "AppRadarPersist.h"
#include "AppRadarGpio.h"
#include "CB_scr.h"

//-------------------------------
// CONFIGURATION SECTION
//-------------------------------

//-------------------------------
// FUNCTION PROTOTYPE SECTION
//-------------------------------
void Initialize_IRQ_Priority(void);

//-------------------------------
// DEFINE SECTION
//-------------------------------
#define APP_UART1_ENABLE 0

//-------------------------------
// ENUM SECTION
//-------------------------------

//-------------------------------
// STRUCT/UNION SECTION
//-------------------------------

//-------------------------------
// GLOBAL VARIABLE SECTION
//-------------------------------
uint8_t g_UWB_TXBANKMEMORY[4096] __attribute__((section("SPECIFIC_UWB_TXBANK_RAMMEMORY"))) ;
uint8_t g_UWB_RXBANKMEMORY[4096] __attribute__((section("SPECIFIC_UWB_RXBANK_RAMMEMORY"))) ;

//-------------------------------
// FUNCTION BODY SECTION
//-------------------------------
/**
 * @brief The main function of the program.
 * 
 * This function serves as the entry point of the program. It is called automatically
 * when the program starts executing. The function contains an infinite loop, which
 * ensures that the program continues running indefinitely.
 * 
 * @return An integer value representing the exit status of the program. 
 *         This function always returns 0, indicating successful execution.
 */
 
 #include "CB_uwbframework.h"
 
int main(void)
{  
	//cb_scr_configure_cpu_clock();	for 128k
	
  // Run RC Timing Calibration once. Calibration done in background after 100ms (NMI handler).
  cb_system_rc_calibration();
  
  // UWB initialization
  cb_system_chip_init();

  // Application Initialization
  app_uart_init();
#if APP_UART1_ENABLE
  app_uart1_init();
#endif
    
  AppRadarGpio_Init();
  AppRadarPersist_Init();

  // Init interrupt Priority of modules
  Initialize_IRQ_Priority();

  cb_uwbsystem_systemconfig_st uwbSystemConfig = {   
    .channelNum           = EN_UWB_Channel_9,
    .bbpllFreqOffest_rf   = 127,
    .powerCode_tx         = 28,
    .operationMode_rx     = EN_UWB_RX_OPERATION_MODE_COEXIST,
  };   

  app_uart_printf("COMMTX v1.0\n");
  app_uart_printf("\n>");
  
  cb_system_uwb_set_system_config(&uwbSystemConfig);

  cb_system_uwb_ram_init(&g_UWB_TXBANKMEMORY,&g_UWB_RXBANKMEMORY,sizeof (g_UWB_TXBANKMEMORY), sizeof (g_UWB_RXBANKMEMORY)); //Initializes only once upon start-up. 

	cb_framework_uwb_init();	
	
  (void)AppRadarPersist_TryAutoStart();
	
	//cb_system_delay_in_ms(50);

	//f,0,40,6,2,38,78,0,1,1,100,32,0,2
	//APP_RadarInit(0, 40, 6, 2, 38, 78, 0, 2, 1, 100, 32, 0, 2);	
	//f,0,40,4,5,0,255,0,1,250,500,8,0,2
	//APP_RadarInit(0,40,4,5,0,255,0,1,250,500,8,0,2);
	
	//cb_system_delay_in_ms(100);
	//g_task_f_execute = APP_TRUE;
	
#if (APP_FREERTOS_ENABLE == APP_TRUE)
  // Init uwb task
  APP_RTOS_Init();
	//start scheduler
	APP_RTOS_StartScheduler();
#else
  // command    : 200 (Freq)
  // pa         : 16
  // scale_bit  : 6
  // gain_idx   : 2
  // num_cirSet : 40
// APP_RadarInit(20, 16, 6, 2, 256);
// APP_RadarStart();
  while(1){
      TaskHandler();
  }
#endif
}

/**
 * @brief Initializes the priority of Interrupt Service Routines (ISRs).
 * 
 * This function sets the priority of various Interrupt Service Routines (ISRs) 
 * to ensure proper handling of interrupts. The priority levels are determined 
 * by the number of bits available for interrupt priority levels (__NVIC_PRIO_BITS).
 * 
 */
void Initialize_IRQ_Priority(void)
{    
//  NVIC_SetPriority(Interrupt0_IRQn             , 1);
//  NVIC_SetPriority(Interrupt1_IRQn             , 1);
//  NVIC_SetPriority(Interrupt2_IRQn             , 1);
//  NVIC_SetPriority(CRYPTO_IRQn                 , 1);
//  NVIC_SetPriority(PKA_IRQn                    , 1);
//  NVIC_SetPriority(TRNG_IRQn                   , 1);
//  NVIC_SetPriority(Interrupt6_IRQn             , 1);
//  NVIC_SetPriority(Interrupt7_IRQn             , 1);
//  NVIC_SetPriority(SPI_IRQn                    , 1);  
    NVIC_SetPriority(UART0_IRQn                  , 2);
#if APP_UART1_ENABLE
    NVIC_SetPriority(UART1_IRQn                  , 1);
#endif
//  NVIC_SetPriority(Interrupt11_IRQn            , 1);
//  NVIC_SetPriority(TIMER_0_IRQn                , 1);
//  NVIC_SetPriority(TIMER_1_IRQn                , 1);
//  NVIC_SetPriority(TIMER_2_IRQn                , 1);
//  NVIC_SetPriority(TIMER_3_IRQn                , 1);
//  NVIC_SetPriority(Interrupt16_IRQn            , 1);
//  NVIC_SetPriority(Interrupt17_IRQn            , 1);
//  NVIC_SetPriority(BLE_IRQn                    , 1);
//  NVIC_SetPriority(Interrupt19_IRQn            , 1);
//  NVIC_SetPriority(Interrupt20_IRQn            , 1);
//  NVIC_SetPriority(UWB_RX0_DONE_IRQn           , 1);
//  NVIC_SetPriority(UWB_RX0_PD_DONE_IRQn        , 1);
//  NVIC_SetPriority(UWB_RX0_SFD_DET_DONE_IRQn   , 1);
//  NVIC_SetPriority(UWB_RX1_DONE_IRQn           , 1);
//  NVIC_SetPriority(UWB_RX1_PD_DONE_IRQn        , 1);
//  NVIC_SetPriority(UWB_RX1_SFD_DET_DONE_IRQn   , 1);
//  NVIC_SetPriority(UWB_RX2_DONE_IRQn           , 1);
//  NVIC_SetPriority(UWB_RX2_PD_DONE_IRQn        , 1);
//  NVIC_SetPriority(UWB_RX2_SFD_DET_DONE_IRQn   , 1);
//  NVIC_SetPriority(UWB_RX_STS_CIR_END_IRQn     , 1);
//  NVIC_SetPriority(UWB_RX_PHR_DETECTED_IRQn    , 1);
//  NVIC_SetPriority(UWB_RX_DONE_IRQn            , 1);
    NVIC_SetPriority(UWB_TX_DONE_IRQn            , 1);
    NVIC_SetPriority(UWB_TX_SFD_MARK_IRQn        , 1);
//  NVIC_SetPriority(Interrupt35_IRQn            , 1);
//  NVIC_SetPriority(Interrupt36_IRQn            , 1);
//  NVIC_SetPriority(Interrupt37_IRQn            , 1);
//  NVIC_SetPriority(Interrupt38_IRQn            , 1);
}
